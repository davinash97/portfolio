
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// src/Modules/triggerSubscribeEmail.js
import fetch from "node-fetch";
var emailHandler = async function(event) {
  if (event.body === null) {
    return {
      statusCode: 400,
      body: JSON.stringify("Payload required")
    };
  }
  const requestBody = JSON.parse(event.body);
  const url = process.env.URL;
  const secret = process.env.NETLIFY_EMAILS_SECRET;
  console.log(url);
  console.log(secret);
  await fetch(`${url}/.netlify/functions/emails/subscribed`, {
    headers: {
      "netlify-emails-secret": secret
    },
    method: "POST",
    body: JSON.stringify({
      from: requestBody.inviteeEmail,
      to: requestBody.subscriberEmail,
      subject: "You've been subscribed",
      parameters: {
        name: requestBody.subscriberName,
        email: requestBody.subscriberEmail
      }
    })
  });
  return {
    statusCode: 200,
    body: JSON.stringify("Subscribe email sent!")
  };
};
var triggerSubscribeEmail_default = { emailHandler };
export {
  triggerSubscribeEmail_default as default
};
